#include <cstdint>
#include <cstring>


extern "C" {
#include <libretro.h>
}